<?xml version="1.0" encoding="UTF-8"?>
<tileset name="desert_x2" tilewidth="32" tileheight="64">
 <image source="../graphics/tiles/desert_x2.png" width="512" height="64"/>
</tileset>
