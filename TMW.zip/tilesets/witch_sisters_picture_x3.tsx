<?xml version="1.0" encoding="UTF-8"?>
<tileset name="witch_sisters_picture_x3" tilewidth="32" tileheight="96">
 <image source="../graphics/tiles/witch_sisters_picture_x3.png" width="64" height="96"/>
</tileset>
