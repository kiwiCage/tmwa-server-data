<?xml version="1.0" encoding="UTF-8"?>
<tileset name="woodland_graveyard_x4" tilewidth="32" tileheight="128">
 <image source="../graphics/tiles/woodland_graveyard_x4.png" width="512" height="256"/>
</tileset>
