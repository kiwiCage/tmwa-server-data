<?xml version="1.0" encoding="UTF-8"?>
<tileset name="barbarians_outdoor" tilewidth="64" tileheight="64">
 <image source="../graphics/tiles/barbarians_outdoor.png" width="192" height="64"/>
</tileset>
