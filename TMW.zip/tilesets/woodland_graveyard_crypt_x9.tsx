<?xml version="1.0" encoding="UTF-8"?>
<tileset name="woodland_graveyard_crypt_x9" tilewidth="32" tileheight="288">
 <image source="../graphics/tiles/woodland_graveyard_crypt.png" width="224" height="288"/>
</tileset>
