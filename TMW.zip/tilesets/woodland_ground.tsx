<?xml version="1.0" encoding="UTF-8"?>
<tileset name="woodland_ground" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/woodland_ground.png" width="512" height="512"/>
</tileset>
