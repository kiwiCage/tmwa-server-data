<?xml version="1.0" encoding="UTF-8"?>
<tileset name="cave_bilevel" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/cave_bilevel.png" width="512" height="512"/>
</tileset>
