<?xml version="1.0" encoding="UTF-8"?>
<tileset name="desert_city_indoors_x3" tilewidth="32" tileheight="96">
 <image source="../graphics/tiles/desert_city_indoors_x3.png" width="480" height="320"/>
</tileset>
